<?php

namespace App\Http\Controllers;

use App\Helpers\Response;
use App\Http\Controllers\Controller;
use App\Http\Requests\ClientRegisterRequest;
use App\Http\Requests\ClientUpdateRequest;
use App\Http\Requests\EmailAuthOrGivenRequest;
use App\Http\Requests\UserDestroyRequest;
use App\Interfaces\ClientRepositoryInterface;
use App\Models\Client;
use Illuminate\Support\Facades\DB;

class ClientController extends Controller
{

    private ClientRepositoryInterface $clientRepository;
    private Response $response;

    public function __construct(ClientRepositoryInterface $clientRepository) {
        $this->clientRepository = $clientRepository;
        $this->response = new Response;
    }

    public function index()
    {
        $clients = Client::all();

        return $this->response->ok([
            'data' => $clients,
            'message' => 'All clients!'
        ]);
    }

    public function store(ClientRegisterRequest $request)
    {
        // if fails
        if(isset($request->validator) && $request->validator->fails()) {
            return $this->response->badRequest('Data is not valid!', $request->validator->errors(), $request->except(['password', 'password_confirmation', 'avatar']));
        }

        DB::beginTransaction();

        try {
            $client = $this->clientRepository->store($request);

            $this->clientRepository->storeAvatar($request->avatar, $client);

            $client->save();

            DB::commit();

            return $this->response->created(['data' => $client], 'client');
        } catch (\Throwable $th) {
            DB::rollback();
            return $this->response->internalServerError($th->getMessage());
        }
    }

    public function show(EmailAuthOrGivenRequest $request)
    {
        // if fails
        if(isset($request->validator) && $request->validator->fails()) {
            return $this->response->badRequest('Data is not valid!', $request->validator->errors(), $request->except(['password', 'password_confirmation', 'card', 'avatar', 'attachments']));
        }
        $client = Client::where('email', $request->email)->first();

        if(!$client) {
            return $this->response->notFound(obj: 'client');
        }

        return $this->response->ok([
            'data' => $client,
            'message' => 'Client is found!',
        ]);
    }

    public function update(ClientUpdateRequest $request)
    {
        // if fails
        if(isset($request->validator) && $request->validator->fails()) {
            return $this->response->badRequest('Data is not valid!', $request->validator->errors(), $request->except(['password', 'password_confirmation', 'card', 'avatar', 'attachments']));
        }

        DB::beginTransaction();

        try {
            $client = $this->clientRepository->update($request, $request->email);

            isset($request->avatar) ? $this->clientRepository->updateAvatar($request->avatar, $client) : null;

            $client->save();

            DB::commit();

            return $this->response->ok([
                'data' => $client,
                'message' => 'Client has been updated successfully!'
            ]);
        } catch (\Throwable $th) {
            DB::rollback();
            return $this->response->internalServerError($th->getMessage());
        }
    }

    public function destroy(EmailAuthOrGivenRequest $request)
    {
        // if fails
        if(isset($request->validator) && $request->validator->fails()) {
            return $this->response->badRequest('Data is not valid!', $request->validator->errors(), $request->all());
        }

        DB::beginTransaction();

        try {
            $client = $this->clientRepository->destroy($request->email);

            DB::commit();

            return $this->response->ok(['data' => $client, 'message' => 'Client has been deleted successfully!']);
        } catch (\Throwable $th) {
            DB::rollback();
            return $this->response->internalServerError($th->getMessage());
        }
    }
}
