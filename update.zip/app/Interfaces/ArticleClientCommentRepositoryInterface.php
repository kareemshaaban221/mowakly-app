<?php

namespace App\Interfaces;

interface ArticleClientCommentRepositoryInterface extends ArticleCommentRepositoryInterface {

}
