<?php

namespace App\Interfaces;

interface ArticleLawyerCommentRepositoryInterface extends ArticleCommentRepositoryInterface {

}
